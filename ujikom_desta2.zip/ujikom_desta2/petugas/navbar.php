<div class="card mt-5">
     		<div class="card-body">
     			<a href="index.php" class="btn btn-secondary">Beranda</a>
     			<a href="data_barang.php" class="btn btn-secondary">Data Barang</a>
     			<a href="pembelian.php" class="btn btn-secondary">Pembelian</a>
     			<a href="../logout.php" class="btn btn-dark">Keluar</a>
     		</div>
     	</div>